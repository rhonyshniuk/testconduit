# -*- coding: utf-8 -*-
"""The user module."""
from . import views  # noqa
